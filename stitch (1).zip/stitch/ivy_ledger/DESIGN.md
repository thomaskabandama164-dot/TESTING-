# Design System Specification: Editorial Intelligence

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Academic Atelier."** 

Education technology often falls into two traps: clinical coldness or juvenile vibrancy. This design system rejects both, opting for a high-end editorial aesthetic that mirrors a prestige university publication. By combining the authority of a refined serif with the precision of a modern sans-serif, we create a "Digital Curator" experience. 

We break the "standard app grid" through intentional asymmetry—using generous, unequal margins and overlapping "floating" containers. The goal is to make a data-heavy attendance app feel like a premium, breathable workspace where information is not just displayed, but curated.

## 2. Color & Tonal Depth
Our palette is rooted in the "Deep Emerald" of academic tradition, balanced by a "Refined Gold" that denotes achievement rather than mere warning.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or containers. 
*   **Boundaries** must be established through tonal shifts (e.g., a `surface-container-low` card resting on a `surface` background).
*   **Separation** is achieved via whitespace (`spacing-8` or `spacing-10`) rather than lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the surface tiers to create "nested" depth:
- **Base Layer:** `surface` (#f8f9fa) – The canvas.
- **Section Layer:** `surface-container-low` (#f3f4f5) – To group related attendance modules.
- **Interactive Layer:** `surface-container-lowest` (#ffffff) – Used for primary data cards to provide a "lifted" feel against the background.
- **Accent Layer:** `primary-container` (#064e3b) – Used sparingly for high-impact summaries.

### The Glass & Gradient Rule
To prevent the UI from feeling "flat" or "templated," use **Glassmorphism** for floating navigation bars or modal overlays. 
- **Glass Token:** Use `surface` at 80% opacity with a `20px` backdrop-blur.
- **Signature Gradient:** For primary CTAs (e.g., "Submit Register"), use a subtle linear gradient from `primary` (#003527) to `primary_container` (#064e3b) at a 135-degree angle. This adds "soul" and a tactile, premium finish.

## 3. Typography
The typographic system relies on the tension between the heritage of **Playfair Display** (Display/Headline) and the utility of **Inter** (Title/Body/Label).

- **Display & Headlines (`notoSerif` / Playfair):** Used for branding, page titles, and high-level statistics. This conveys authority and "The Academic Atelier" spirit.
- **Title, Body, & Labels (`inter`):** Used for student names, timestamps, and data grids. It ensures maximum legibility in high-density attendance lists.

**Editorial Hierarchy:** Use `display-lg` for hero numbers (e.g., "98% Attendance") paired with a `label-md` in all-caps with 0.05em letter spacing to create a sophisticated, high-contrast look.

## 4. Elevation & Depth
We eschew traditional material shadows in favor of **Tonal Layering** and **Ambient Light.**

### The Layering Principle
Depth is achieved by stacking. A `surface-container-highest` element should never sit directly on a `surface-lowest` element; they must move through the hierarchy to feel natural.

### Ambient Shadows
When an element must float (e.g., a floating action button or a dropdown):
- **Blur:** 24px - 32px.
- **Opacity:** 4% - 6%.
- **Color:** Use a tinted shadow (`on-surface` #191c1d) rather than pure black. This mimics natural light diffusing through a high-end gallery space.

### The "Ghost Border" Fallback
If accessibility requirements demand a border, use a **Ghost Border**: `outline-variant` at 15% opacity. This provides a "suggestion" of a boundary without cluttering the visual field.

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary-container`), `roundness-md` (0.75rem), white text. Transition: 200ms ease-in-out on hover to increase gradient saturation.
- **Secondary:** `surface-container-high` background with `on-surface` text. No border.
- **Tertiary (Ghost):** No background. `primary` text. Use for low-emphasis actions like "Cancel" or "View Details."

### Cards & Lists
- **Rule:** Forbid the use of divider lines between student rows.
- **Structure:** Use `spacing-3` vertical padding. Distinguish rows using a subtle "Zebra" effect with `surface-container-low` or simply by providing ample `spacing-4` between items.
- **Rounding:** All cards must use `roundness-lg` (1rem) to soften the "data-heavy" nature of the app.

### Input Fields
- **State:** Fields should be `surface-container-lowest` with a `Ghost Border`. 
- **Focus:** Transition the border to `primary` (#003527) and add a soft `primary-fixed` (20% opacity) outer glow.

### Signature Component: The "Attendance Pulse"
A custom component for this system: A horizontal bar using a gradient from `primary` to `tertiary_fixed` (Gold) to show attendance trends, housed in a `surface-container-highest` track.

## 6. Do's and Don'ts

### Do
- **Do** use asymmetrical layouts (e.g., a wide left column for the register and a narrow right column for "Insights").
- **Do** lean heavily on `surface-container` shifts to define hierarchy.
- **Do** allow `headline-lg` serif text to overlap slightly into a `surface-container` to create an editorial feel.

### Don't
- **Don't** use 1px solid black or grey borders.
- **Don't** use standard "drop shadows" with high opacity.
- **Don't** crowd the screen. If a section feels tight, increase the spacing to the next tier in the scale (e.g., move from `spacing-4` to `spacing-6`).
- **Don't** use the Gold (`tertiary`) for large backgrounds; keep it as a "jewelry" accent for highlights, alerts, or achievement markers.